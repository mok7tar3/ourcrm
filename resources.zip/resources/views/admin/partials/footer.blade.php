<!-- [ Main Content ] end -->
<footer class="dash-footer">
    <div class="footer-wrapper">
        <div class="py-1">
            <p class="text-muted">{{ $settings['FOOTER_TEXT'] }}</p>
        </div>
        <div class="py-1">
            <ul class="list-inline m-0">

            </ul>
        </div>
    </div>
</footer>
