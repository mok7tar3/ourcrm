@component('mail::message')
# Hello

The body of your message.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
